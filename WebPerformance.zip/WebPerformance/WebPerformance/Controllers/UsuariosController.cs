﻿using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebPerformance.Model;

namespace WebPerformance.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly Contexto _contexto;
        public UsuariosController(Contexto contexto)
        {
            _contexto = contexto;
        }

        [HttpGet("Usuarios_Link_Core")]
        public async Task<int> Usuarios_Link_Core()
        {

           return  await _contexto.Usuario.AsNoTracking().CountAsync();
          
        }

        [HttpGet("Usuarios_Core_Async")]
        public async Task<int> Usuarios_Core_Async()
        {

            var listaRetorno = await  _contexto.Usuario.FromSqlRaw("ListarUsuarios").AsNoTracking().ToListAsync();
            return listaRetorno.Count;

        }

        [HttpGet("Usuarios_Core")]
        public int Usuarios_Core()
        {

            var listaRetorno = _contexto.Usuario.FromSqlRaw("ListarUsuarios").AsNoTracking().ToList();
            return listaRetorno.Count;

        }

        [HttpGet("Usuarios_Dapper")]
        public async Task<int> Usuarios_Dapper()
        {


            using (var connection =
                new SqlConnection("Data Source=DESKTOP-HVNTI80\\DESENVOLVIMENTO;Initial Catalog=crud_procedure_mvc;Integrated Security=False;User ID=sa;Password=1234;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False"))
            {

                var usuarios = connection.QueryAsync<Usuario>("ListarUsuarios").Result;

                return usuarios.Count();


            }
        }

    }
}
